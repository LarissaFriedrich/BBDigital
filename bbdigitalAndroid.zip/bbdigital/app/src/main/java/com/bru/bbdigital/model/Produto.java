package com.bru.bbdigital.model;

import androidx.annotation.NonNull;

public class Produto {

    public int id;
    public String nomeCompleto, nomeLivro, email, fone;

    public Produto() {

    }

    public Produto(int id, String nomeCompleto, String nomeLivro, String email, String fone) {
        this.id = id;
        this.nomeCompleto = nomeCompleto;
        this.nomeLivro = nomeLivro;
        this.email = email;
        this.fone = fone;

    }

    public Produto(String nomeCompleto, String nomeLivro, String email, String fone) {
        this.nomeCompleto = nomeCompleto;
        this.nomeLivro = nomeLivro;
        this.email = email;
        this.fone = fone;

    }

    @NonNull
    @Override
    public String toString() {
        return nomeCompleto + " | " + nomeLivro + " | " + email +
                " | " + fone ;
    }

}
