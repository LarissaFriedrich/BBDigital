package com.bru.bbdigital;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private EditText etNomeCompleto, etEmail, tdFone;
    private Button btSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNomeCompleto = findViewById(R.id.etNomeCompleto);
        etEmail = findViewById(R.id.etEmail);
        tdFone = findViewById(R.id.tdFone);
        btSalvar = findViewById(R.id.btSalvar);

        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvar();
            }
        });
    }

    private void salvar() {
        String nomeCompleto = etNomeCompleto.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String fone = tdFone.getText().toString().trim();

        if (nomeCompleto.isEmpty() || email.isEmpty() || fone.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
        } else {
            // Enviar dados para a URL relacionada ao cliente
            enviarDados("https://app-faculdade-b072289ff798.herokuapp.com/costumer", nomeCompleto, email, fone);
        }
    }

    private void enviarDados(String url, String nome, String email, String telefone) {
        String dados[]={nome,email,telefone};
        JSONObject jsonObject = new JSONObject();
        //Toast.makeText(MainActivity.this, "um"+dados[0]+dados[1]+dados[2],Toast.LENGTH_LONG).show();
        try {
            jsonObject.put("nome", dados[0]);
            jsonObject.put("email", dados[1]);
            jsonObject.put("telefone", dados[2]);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
                Request.Method.POST,
                url,
                jsonObject,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // Trata a resposta do servidor
                        if (response != null) {
                            Toast.makeText(MainActivity.this, "Dados enviados com sucesso para " + url, Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Resposta vazia do servidor", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Trata erros de requisição
                        Toast.makeText(MainActivity.this, "Erro " + url + ": " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
        );

        // Adiciona a requisição à fila
        requestQueue.add(jsonObjectRequest);

        // Limpa os campos após o envio
        etNomeCompleto.setText("");
        etEmail.setText("");
        tdFone.setText("");
    }
}
